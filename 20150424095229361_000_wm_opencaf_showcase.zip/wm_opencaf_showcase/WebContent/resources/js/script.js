Event.waitUntilLoaded(function() {
    $('time').innerHTML = new Date().toTimeString();
});