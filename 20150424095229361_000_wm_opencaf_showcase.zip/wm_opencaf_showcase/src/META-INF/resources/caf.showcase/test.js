function showcaseTest() {
	alert("hello from javascript file loaded from resource library!");
	return false;
}
